## 传奇梭客(ShadowsocksR 修改版)
基于 ShadowsocksR 小范围修改的服务端，仅适用于 LegendSock 前端使用。

原版未修改请查阅: https://github.com/breakwa11/shadowsocks/tree/manyuser
