#!/bin/bash
cd `dirname $0`
tail -f /usr/local/legendsock/shadowsocks.log
